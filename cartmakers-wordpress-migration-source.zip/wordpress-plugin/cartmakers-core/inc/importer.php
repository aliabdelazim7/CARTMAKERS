<?php
if (!defined('ABSPATH')) { exit; }
function cm_seed_projects() {
    return array(
        array('Eg Mom\'s Recipes','Editorial / Food Blog','مجلة وصفات مصرية','eg-moms-recipes.webp','تجربة Editorial تحمل قصة أكل بيتي مصري وتحوّلها إلى وصفات وتصنيفات قابلة للاكتشاف.','https://egmomrecipes.unaux.com/?i=1'),
        array('Vervac Animal Care','E-commerce / Animal Care','رعاية الحيوانات في الخليج','vervac.webp','علامة بحرينية تجمع المنتجات، قصة العلامة، وتصنيفات العناية بالحيوانات داخل تجربة متجر واسعة.','https://vervac.com/'),
        array('Velora Flowers','E-commerce / Flowers','متجر زهور ومناسبات','velora.webp','متجر زهور يضع المناسبات والتوصيل وتجربة الهدية في مقدمة الرحلة.','https://velora-eg.online/'),
        array('Pharaohs Stone','Corporate / Construction','مقاولات الحجر والدبش','pharaohs-stone.webp','موقع شركة مقاولات عربية يشرح تخصصات الحجر والدبش ويعرض نماذج من المشاريع.','https://pharaohsstone.com/'),
        array('Islamisch Akademisch','Education / Quran Academy','Premium Online Quran Academy','islamisch-akademisch.webp','أكاديمية ألمانية اللغة للتعلم الفردي في القرآن والتجويد والدراسات الإسلامية.','https://islamisch-akademisch.com'),
        array('Ufuqar News Magazine','Editorial / Arabic News','مجلة إخبارية عربية','ufuqar.webp','بوابة أخبار عربية تعتمد على الأخبار العاجلة، الأقسام المتعددة، وواجهة كثيفة للمحتوى اليومي.','https://ufuqar.com/'),
        array('Selim Marketing','Marketing Services / E-commerce','متجر خدمات تسويق','selim-marketing.webp','متجر عربي للخدمات التسويقية يقسم العرض حسب المنصة ويقرب قرار الشراء.','https://selimmarketing.com'),
        array('9TEN Store','E-commerce / Footwear','متجر أحذية عربي','9ten.webp','متجر RTL للأحذية يقسم التجربة إلى رجالي ونسائي ويقود إلى المنتجات الجديدة.','https://9tenstore-eg.com'),
        array('Black Horses','Corporate / Engineering','موقع شركة هندسية','black-horses.webp','تجربة Corporate تقود الزائر من الوعد الهندسي إلى الخدمات والمشاريع المميزة.','https://blackhorses.sa/'),
        array('Sandy Collection','E-commerce / Jewelry','متجر مجوهرات','sandy-collection.webp','واجهة متجر مجوهرات تعتمد على الصورة، الكولكشن، والسعر لتقريب قرار الشراء.','https://sandy-collection.com'),
        array('La Maison Française','Education / Landing Page','أكاديمية لغة','la-maison-francaise.webp','Landing Page موجهة للأهل تشرح التعلم، المتابعة، والخطوة الأولى.','https://lamaisonfrançaise.com'),
        array('OPREVA','E-commerce / Skincare','متجر عناية بالبشرة','opreva.webp','متجر Skincare يربط عرض المنتجات بالمكونات والفئات والعروض.','https://opreva-eg.com/'),
        array('MS Uniforms','E-commerce / Fashion','متجر يونيفورم طبي','ms-uniforms.webp','تجربة Catalog لمنتجات طبية تعتمد على المقاسات، الألوان، والتصنيفات.','https://ms-uniforms.com/'),
        array('Quran Academy','Education / Landing Page','أكاديمية تعليم أونلاين','quran-academy.webp','Landing Page تعليمية تشرح البرامج وتضع التسجيل في مقدمة الرحلة.','https://quranacademyy.com/'),
        array('Shopping Online Store','E-commerce / Outdoor','معدات تخييم ومغامرات','shopping-online-store.webp','متجر عربي لمعدات التخييم والمغامرات يعرض المنتجات ومحتوى يساعد على الاختيار.',''),
    );
}
function cm_seed_services() {
    return array(
        array('تطوير WordPress','نبني مواقع WordPress مرنة للبراندات والشركات، مع بنية محتوى واضحة، Responsive، SEO أساسي، وتسليم يمكن تشغيله.'),
        array('تطوير Shopify والمنصات التجارية','نساعد العلامات النامية على إطلاق متجر Shopify أو منصة تجارة مناسبة، من الـTheme والكتالوج حتى Checkout والتشغيل.'),
        array('تحسين Checkout وCRO','نراجع تجربة Checkout ونقاط التسريب في المتجر الإلكتروني، من صفحة المنتج حتى الدفع والتأكيد والتوصيل.'),
        array('Tracking وAnalytics','نثبت أساسًا عمليًا للـTracking وAnalytics حتى تعرف العلامات أين يأتي الطلب وأين تتوقف الرحلة.'),
        array('تصميم موقع تعريفي','نبني مواقع تعريفية للشركات والبراندات تشرح العرض، تثبت الثقة، وتحوّل الزيارة إلى خطوة تواصل واضحة.'),
    );
}
function cm_import_page() {
    if (!current_user_can('manage_options')) { return; }
    if (isset($_POST['cm_import_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['cm_import_nonce'])), 'cm_import')) {
        $count = 0;
        foreach (cm_seed_projects() as $project) {
            if (get_page_by_title($project[0], OBJECT, 'cm_project')) { continue; }
            $id = wp_insert_post(array('post_type'=>'cm_project','post_title'=>$project[0],'post_excerpt'=>$project[4],'post_status'=>'publish','menu_order'=>$count));
            if ($id && !is_wp_error($id)) {
                update_post_meta($id, 'cm_external_url', $project[5]);
                update_post_meta($id, 'cm_category_label', $project[1]);
                update_post_meta($id, 'cm_tag', $project[2]);
                update_post_meta($id, 'cm_platform', strpos($project[1], 'E-commerce') !== false ? 'E-commerce' : 'Website');
                $count++;
            }
        }
        foreach (cm_seed_services() as $service) {
            if (get_page_by_title($service[0], OBJECT, 'cm_service')) { continue; }
            wp_insert_post(array('post_type'=>'cm_service','post_title'=>$service[0],'post_content'=>$service[1],'post_status'=>'publish'));
        }
        echo '<div class="notice notice-success"><p>Imported '.esc_html($count).' portfolio projects. Add featured images from the Media Library after upload.</p></div>';
    }
    ?><div class="wrap"><h1>CartMakers Content Importer</h1><p>This seeds the known CartMakers portfolio and service titles. It does not overwrite existing entries or upload files.</p><form method="post"><?php wp_nonce_field('cm_import', 'cm_import_nonce'); submit_button('Import Existing Content'); ?></form></div><?php
}
function cm_import_menu() { add_management_page('CartMakers Importer','CartMakers Importer','manage_options','cm-import','cm_import_page'); }
add_action('admin_menu','cm_import_menu');
